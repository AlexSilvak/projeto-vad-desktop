import path from "node:path";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
  server: {
    host: true,
    proxy: { "/ws": { target: "ws://localhost:8765", ws: true } },
  },
  build: { chunkSizeWarningLimit: 900 },
});
