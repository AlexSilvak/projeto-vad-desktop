import * as React from "react";
import { cn } from "@/lib/utils";

const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("rounded-lg border bg-card/70 text-card-foreground backdrop-blur-xl", className)} {...props} />
));
Card.displayName = "Card";
export { Card };
